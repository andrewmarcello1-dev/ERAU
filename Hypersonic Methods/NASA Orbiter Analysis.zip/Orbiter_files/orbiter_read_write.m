clear
clc
close all

%{
=======================================================
This script calculates lift, drag, and pitching moment
coeffiecients and displays the pressure contour on the 
NASA space shuttle geometry 
=======================================================
%}

% Main script to run the aerodynamic analysis
main();

% --- Main Function ---
function main()
    % READ TRIANGULATED SURFACE DOMAIN
    [XYZ1, NODE1] = read_tecplot_mesh('input_tecplot_FA25.dat');

    % FREESTREAM / GAS
    gas_data = setup_gas_properties();
    
    % REFERENCE AREAS & CHORD
    [S_ref, S_ref_eff, c_ref, x_ref, y_ref, z_ref] = get_model_properties(XYZ1, NODE1);
    
    % AOA SWEEP & COEFFICIENT CALCULATION
    alpha_range = 0:1:80;
    [CL, CD, CM, alpha_CLmax, CLmax, CD_CLmax, CM_CLmax] = ...
        sweep_alpha(alpha_range, XYZ1, NODE1, S_ref_eff, c_ref, x_ref, y_ref, z_ref, gas_data);

    % REPORT & PLOTS
    report_and_plot(alpha_range, CL, CD, CM, CLmax, alpha_CLmax, CD_CLmax, CM_CLmax, S_ref, S_ref_eff, c_ref, gas_data);
    
    % EVALUATE PITCH STABILITY AT A SPECIFIC AOA
    alpha_eval_deg = 54;
    idx_53 = find(alpha_range == 53);
    idx_55 = find(alpha_range == 55);
    
    if isempty(idx_53) || isempty(idx_55)
        fprintf('\nError: Pitch stability evaluation requires AOA data at 53 and 55 degrees.\n');
    else
        % Use central difference for second-order accuracy
        dCM_dalpha_rad = (CM(idx_55) - CM(idx_53)) / deg2rad(55 - 53);
        
        fprintf('\n--- Pitch Stability Analysis ---\n');
        fprintf('Evaluated at Alpha = %.1f deg (using a central difference).\n', alpha_eval_deg);
        fprintf('Derivative of Pitch Moment Coefficient (dCM/d_alpha) = %.4f per radian.\n', dCM_dalpha_rad);
        
        if dCM_dalpha_rad < 0
            fprintf('The orbiter is directionally stable in the pitch plane.\n');
        else
            fprintf('The orbiter is directionally unstable in the pitch plane.\n');
        end
        fprintf('------------------------------\n');
    end

    % NODAL Cp & PRESSURE FOR CONTOURS
    alpha_plot_deg = alpha_CLmax;
    [Cp_nodes, P_nodes] = calculate_nodal_pressure(XYZ1, NODE1, alpha_plot_deg, gas_data);
    
    % Plot the pressure contour on the surface
    plot_surface_contour(XYZ1, NODE1, P_nodes, alpha_plot_deg);
    
    fprintf('Maximum nodal pressure at alpha = %.1f deg: %.3e Pa\n', alpha_plot_deg, max(P_nodes));

    % EXPORT DATA TO TECPLOT FILE
    export_tecplot_data(XYZ1, NODE1, Cp_nodes);
end

% --- Helper Functions ---

function [XYZ, NODE] = read_tecplot_mesh(filename)
    fileID = fopen(filename, 'r');
    if fileID == -1
        error('File not found: %s', filename);
    end
    SIZE = fscanf(fileID, '%8i', 2);
    n_nodes = SIZE(1);
    n_elements = SIZE(2);
    
    XYZ = fscanf(fileID, '%e', [3, n_nodes])';
    NODE = fscanf(fileID, '%i', [3, n_elements])';
    fclose(fileID);
end

function gas_data = setup_gas_properties()
    gas_data.gamma = 1.3;
    gas_data.M_inf = 8.0;
    gas_data.R = 287.05;
    gas_data.T_inf = 227.0;
    gas_data.p_inf = 1090.0;
    
    gas_data.rho_inf = gas_data.p_inf / (gas_data.R * gas_data.T_inf);
    gas_data.a_inf = sqrt(gas_data.gamma * gas_data.R * gas_data.T_inf);
    gas_data.V_inf = gas_data.M_inf * gas_data.a_inf;
    gas_data.q_inf = 0.5 * gas_data.rho_inf * gas_data.V_inf^2;
    
    num = ((gas_data.gamma + 1)^2 * gas_data.M_inf^2);
    den = (4 * gas_data.gamma * gas_data.M_inf^2 - 2 * (gas_data.gamma - 1));
    fac1 = (num / den)^(gas_data.gamma / (gas_data.gamma - 1));
    fac2 = (1 - gas_data.gamma + 2 * gas_data.gamma * gas_data.M_inf^2) / (gas_data.gamma + 1);
    gas_data.Po2_over_Pinf = fac1 * fac2;
    gas_data.Cp_max = (2 / (gas_data.gamma * gas_data.M_inf^2)) * (gas_data.Po2_over_Pinf - 1);
    
    fprintf('Cp_max (Rayleigh–Pitot) = %.3f\n', gas_data.Cp_max);
end

function [S_planform, S_ref_eff, c_ref, x_ref, y_ref, z_ref] = get_model_properties(XYZ, NODE)
    model_center = mean(XYZ, 1);
    
    S_planform = 0;
    A_wind90 = 0;
    Vhat90 = [0, 0, 1];
    
    for i = 1:size(NODE, 1)
        v1 = XYZ(NODE(i, 1), :);
        v2 = XYZ(NODE(i, 2), :);
        v3 = XYZ(NODE(i, 3), :);
        
        n_raw = cross(v2 - v1, v3 - v1);
        A_panel = 0.5 * norm(n_raw);
        if A_panel < eps, continue; end
        n_hat = n_raw / norm(n_raw);
        cen = (v1 + v2 + v3) / 3;
        if dot(n_hat, cen - model_center) < 0
            n_hat = -n_hat;
        end
        
        if n_hat(3) < 0
            S_planform = S_planform + A_panel * abs(n_hat(3));
        end
        
        s = max(0.0, -dot(n_hat, Vhat90));
        A_wind90 = A_wind90 + A_panel * s;
    end
    
    S_ref_eff = A_wind90;
    c_ref = max(XYZ(:, 1)) - min(XYZ(:, 1));
    
    x_ref = 1.810; y_ref = 0; z_ref = 0.105;
    
    fprintf('Reference area (bottom planform projected) S_ref = %.6f\n', S_planform);
    fprintf('Effective reference area (windward at 90°) S_ref_eff = %.6f\n', S_ref_eff);
    fprintf('Chord (global x-extent) c_ref = %.6f\n', c_ref);
end

function [CL, CD, CM, alpha_CLmax, CLmax, CD_CLmax, CM_CLmax] = ...
    sweep_alpha(alpha_range, XYZ, NODE, S_ref_eff, c_ref, x_ref, y_ref, z_ref, gas_data)
    
    nA = numel(alpha_range);
    CL = zeros(1, nA);
    CD = zeros(1, nA);
    CM = zeros(1, nA);
    
    model_center = mean(XYZ, 1);
    
    for ia = 1:nA
        alpha = deg2rad(alpha_range(ia));
        Vhat = [cos(alpha), 0, sin(alpha)];
        Vhat = Vhat / norm(Vhat);
        
        eD = Vhat;
        eL = [0, 0, 1] - dot([0, 0, 1], eD) * eD;
        eL = eL / norm(eL);
        ey = [0, 1, 0];
        
        F_total = [0, 0, 0];
        M_total = [0, 0, 0];
        
        for i = 1:size(NODE, 1)
            v1 = XYZ(NODE(i, 1), :);
            v2 = XYZ(NODE(i, 2), :);
            v3 = XYZ(NODE(i, 3), :);
            
            n_raw = cross(v2 - v1, v3 - v1);
            A_panel = 0.5 * norm(n_raw);
            if A_panel < eps, continue; end
            
            n_hat = n_raw / norm(n_raw);
            cen = (v1 + v2 + v3) / 3;
            if dot(n_hat, cen - model_center) < 0
                n_hat = -n_hat;
            end
            
            s = max(0.0, -dot(Vhat, n_hat));
            Cp = gas_data.Cp_max * s^2;
            
            Fp = -Cp * gas_data.q_inf * A_panel * n_hat;
            F_total = F_total + Fp;
            
            r = cen - [x_ref, y_ref, z_ref];
            M_total = M_total + cross(r, Fp);
        end
        
        D = dot(F_total, eD);
        L = dot(F_total, eL);
        My = dot(M_total, ey);
        
        CD(ia) = D / (gas_data.q_inf * S_ref_eff);
        CL(ia) = L / (gas_data.q_inf * S_ref_eff);
        CM(ia) = My / (gas_data.q_inf * S_ref_eff * c_ref);
    end
    
    [CLmax, idx] = max(CL);
    alpha_CLmax = alpha_range(idx);
    CD_CLmax = CD(idx);
    CM_CLmax = CM(idx);
end

function report_and_plot(alpha_range, CL, CD, CM, CLmax, alpha_CLmax, CD_CLmax, CM_CLmax, S_ref, S_ref_eff, c_ref, gas_data)
    fprintf('\nSanity checks:\n');
    fprintf('  q_inf = %.3e Pa\n', gas_data.q_inf);
    fprintf('  Max C_L = %.3f at alpha = %.1f deg\n', CLmax, alpha_CLmax);
    fprintf('    Corresponding C_D = %.3f, C_M = %.3f\n', CD_CLmax, CM_CLmax);
    fprintf('  S_ref (planform bottom) = %.3f (mesh units^2)\n', S_ref);
    fprintf('  S_ref_eff (windward 90°) = %.3f (mesh units^2)\n', S_ref_eff);
    fprintf('  c_ref = %.3f (mesh units)\n', c_ref);
    
    [Max,ind] = max(CL);
    CL_CFD = 0.6962;
    CD_CFD = 1.0162;
    CM_CFD = -0.0207;
    
    figure; plot(alpha_range, CL, 'b-o', 'LineWidth', 1.5, 'MarkerFaceColor', 'b'); grid on;
    xlabel('\alpha [deg]'); ylabel('C_L'); title('Lift Coefficient vs AOA');
    hold on; plot(alpha_range(ind), CL(ind), 'o', 'MarkerSize', 12, 'MarkerFaceColor', 'y');
    hold on; plot(alpha_range(ind), CL_CFD, 'd', 'MarkerSize', 12, 'MarkerFaceColor', 'y');
    legend('AOA vs. CL','Max MATLAB','CL CFD')
    
    figure; plot(alpha_range, CD, 'r-s', 'LineWidth', 1.5, 'MarkerFaceColor', 'r'); grid on;
    xlabel('\alpha [deg]'); ylabel('C_D'); title('Drag Coefficient vs AOA');
    hold on; plot(alpha_range(ind), CD(ind), 'o', 'MarkerSize', 12, 'MarkerFaceColor', 'y');
    hold on; plot(alpha_range(ind), CD_CFD, 'd', 'MarkerSize', 12, 'MarkerFaceColor', 'y');
    legend('AOA vs. CD','Max MATLAB','CD CFD')
    
    figure; plot(alpha_range, CM, 'k-^', 'LineWidth', 1.5, 'MarkerFaceColor', 'k'); grid on;
    xlabel('\alpha [deg]'); ylabel('C_M'); title('Pitching Moment vs AOA');
    hold on; plot(alpha_range(ind), CM(ind), 'o', 'MarkerSize', 12, 'MarkerFaceColor', 'y');
    hold on; plot(alpha_range(ind), CM_CFD, 'd', 'MarkerSize', 12, 'MarkerFaceColor', 'y');
    legend('AOA vs. CM','Max MATLAB','CM CFD')
end

function [Cp_nodes, P_nodes] = calculate_nodal_pressure(XYZ, NODE, alpha_plot_deg, gas_data)
    alpha_plot = deg2rad(alpha_plot_deg);
    Vhat_plot = [cos(alpha_plot), 0, sin(alpha_plot)];
    Vhat_plot = Vhat_plot / norm(Vhat_plot);
    
    Cp_nodes = zeros(size(XYZ, 1), 1);
    A_nodes = zeros(size(XYZ, 1), 1);
    model_center = mean(XYZ, 1);
    
    for i = 1:size(NODE, 1)
        nds = NODE(i, :);
        v1 = XYZ(nds(1), :); v2 = XYZ(nds(2), :); v3 = XYZ(nds(3), :);
        
        n_raw = cross(v2 - v1, v3 - v1);
        A_panel = 0.5 * norm(n_raw);
        if A_panel < eps, continue; end
        
        n_hat = n_raw / norm(n_raw);
        cen = (v1 + v2 + v3) / 3;
        if dot(n_hat, cen - model_center) < 0
            n_hat = -n_hat;
        end
        
        s = max(0.0, -dot(Vhat_plot, n_hat));
        Cp = gas_data.Cp_max * s^2;
        
        w = A_panel / 3;
        Cp_nodes(nds(1)) = Cp_nodes(nds(1)) + Cp * w;
        A_nodes(nds(1)) = A_nodes(nds(1)) + w;
        Cp_nodes(nds(2)) = Cp_nodes(nds(2)) + Cp * w;
        A_nodes(nds(2)) = A_nodes(nds(2)) + w;
        Cp_nodes(nds(3)) = Cp_nodes(nds(3)) + Cp * w;
        A_nodes(nds(3)) = A_nodes(nds(3)) + w;
    end
    
    Cp_nodes = Cp_nodes ./ max(A_nodes, eps);
    P_nodes = gas_data.p_inf + Cp_nodes * gas_data.q_inf;
end

function plot_surface_contour(XYZ, NODE, P_nodes, alpha_plot_deg)
    figure;
    
    % Plot the surface using the patch command
    patch('Vertices', XYZ, 'Faces', NODE, ...
          'FaceVertexCData', P_nodes, 'FaceColor', 'interp', ...
          'EdgeColor', 'none');
      
    axis equal;
    colormap('jet');
    colorbar;
    xlabel('X');
    ylabel('Y');
    zlabel('Z');
    title(sprintf('Surface Pressure Contour at \\alpha = %.1f deg', alpha_plot_deg));
    view(3);
    camlight;
    lighting phong;
end

function export_tecplot_data(XYZ1, NODE1, Cp_nodes)
    % Create a combined array with XYZ coordinates and pressure coefficient
    XYZCP1 = [XYZ1, Cp_nodes];
    
    % Open file for writing
    fileID = fopen('output_tecplot.dat', 'w');
    if fileID == -1
        error('Could not open output file.');
    end
    
    % Write a simplified header for Tecplot
    fprintf(fileID, 'VARIABLES = "X", "Y", "Z", "Cp"\n');
    fprintf(fileID, 'ZONE N=%d, E=%d, DATAPACKING=POINT, ZONETYPE=FETRIANGLE\n', size(XYZ1, 1), size(NODE1, 1));
    
    % WRITE DOMAIN
    for i=1:size(XYZCP1, 1)
        fprintf(fileID, '%e  %e  %e  %e\n', XYZCP1(i,1), XYZCP1(i,2), XYZCP1(i,3), XYZCP1(i,4));
    end
    
    % Write element connectivity
    for i=1:size(NODE1, 1)
        fprintf(fileID, '%i   %i  %i\n', NODE1(i,1), NODE1(i,2), NODE1(i,3));
    end
    
    fclose(fileID);
    fprintf('\nData exported to output_tecplot.dat\n');
    fprintf('NOTE: You must manually replace the header with the full header from your input file.\n');
end
